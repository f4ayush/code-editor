# Code Editor

This is a code editor which is developed for the hiring process of Playment Front end developer

## For code set up

In the project directory, you can run:

### `npm install`

To install the dependencies used in this project.

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

